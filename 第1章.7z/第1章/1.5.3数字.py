# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 18:40:06 2025

@author: Administrator
"""

x=3+5j #x 为复数
print(x.real) #查看复数实部
print(x.imag) #查看复数虚部
y=5+3j #y 为复数
print(x+y) #复数之间的算术运算