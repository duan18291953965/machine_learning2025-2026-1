# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 13:36:25 2025

@author: Administrator
"""

plt.figure(figsize=(4,2)) #创建指定大小的窗体
plt.axis([-1, 2, -2, 4]) #设定 x、y 坐标轴范围
plt.xlabel('X values') #设定 x 轴标签
plt.ylabel('Y values') #设定 y 轴标签
plt.title('Test') #设定标题
plt.show() #显示
